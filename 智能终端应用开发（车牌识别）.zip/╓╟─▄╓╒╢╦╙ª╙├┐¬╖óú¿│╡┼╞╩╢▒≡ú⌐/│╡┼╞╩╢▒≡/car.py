import requests
import json
import base64

def car(a,b):
  url = 'http://ai.heclouds.com:9090/v1/aiApi/picture/NUMBER_PLATE_RECOGNITION'
  headers ={
    'Content-Type':'application/json',
    'Login-Token':a
    }

# 打开图片文件
  file = open(b,'rb')

# 将其转为base64信息
  str = base64.b64encode(file.read()).decode()

# 关闭打开的文件
  file.close()

# 构造接口调用参数
  data = {
    'type':'GPU', #可选参数，填入“GPU”则代表使用GPU版本api，否则使用CPU版本api
    'picture':[str]
  }

# POST 方式调用
  req = requests.post(url,data=json.dumps(data),headers=headers)
  return req.text

