## 1.进终端现在Django包

#####        pip install django



## 2.用pycharm安装配置

###            1.用终端的方式建立 pycharm

######                    进入python39中的 scripts 文件夹中的 django-admin.exe 中 然后执行 startproject 项目名称

######                    或者 django-admin startproject

###            2.用pycharm的方式

​                   ![image-20220417233137890](图像/image-20220417233137890.png)

## 3.setting配置

![image-20220417233707957](图像/image-20220417233707957.png)

### 数据库配置

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'wangzimo',
        'USER':'root',
        'PASSWORD':'woailulu5201314',
        'HOST':'localhost',
        'PORT':'3306',

    }
}
```

