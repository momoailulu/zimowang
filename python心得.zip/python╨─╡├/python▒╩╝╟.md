# 王梓默python心得笔记

## 1.变量

### *变量名要求**



```
### 1.变量名只能包含字母、数字、下划线
# 2.只能以字母或下划线开头
# 3.不能是python的关键字
# 4.尽量有实际意义
name = 'zhangsan'
age = 18
# 5.当有多个单词组成时，用下划线连接
stu_class = '一班'
#6.一般不用驼峰命名法
stuClassName = '二班'
```

### **变量名练习题**

```
# 第一题（数字之间可以直接运算）
age = 18
new_age = age + 1
print(new_age)

# 第二题（字符串之间使用 + 进行字符串拼接）
city = 'xingtai'
school = city + 'university'
print(school)

# 第三题 （字符串与数字之间不能进行拼接，会报错）
# name = 'benbentu'
# age = name + 18
# print(age)

# 第四题   字符串* n(n为int)，将字符串重复输出n次
name = 'benbentu'
n_name = name*3
print(n_name)

# 第五题 先执行右侧表达式，再执行赋值操作
age = 18
value = age > 19
print(value)
```

### 常见的数据类型

```
# 字符串
'hello'
"hello"
"'hello'"

# 整形
6666 #整形
'6666'  #字符串

# 布尔值
false
true
```

### **注释**

```
#    单行注释

'''
多行注释

'''
```

### **输入**

```
# 1.实例1
user_name = input('请输入你的姓名：')
message = user_name + '化学专业'
print(message)
# input输出的永远是字符串

# 2.实例2
user_name = input('请输入你的名字：')
password = input('请输入你的密码')
content = '你的姓名是：'+user_name+'你的密码是'+password
print(content)
```

### **输出**

```
print('要输出的内容')
```

## 2.阶段一作业

### **作业一**

```
count = 66
while True:
    a = int(input('请输入一个数字'))
    if a == count:
     print('猜测正确')
     break
    elif a >= count:
        print('猜的大了')
    else:
        print('小了')
```

### **作业二**

```
count = 66
n = 0
while n < 3:
         a = int(input('请输入一个数字'))
         if a == 66:
           print('猜测正确')
           break
         else:
            n = n + 1
else:
    print('大笨蛋')
```

### **作业三**

```
n = 0
while n < 3:
 usename = input('请输入用户名')
 a = int(input('请输入登录密码'))
 if a == 123 and usename == 'zhangsan':
  print('登陆成功')
  break
 else:
     print('用户名或密码错误')
     n = n + 1
else:
    print('登陆失败')
```

### **作业四**

```
n = 0
while n < 3:
     usename = input('请输入用户名')
     a = int(input('请输入密码'))
     if usename == 'zhangsan' and a == 123:
       print('登陆成功')
     else:
         print('用户名或密码输入错误')
         n += 1
else:
    print('登陆失败')
    b = input('是否继续,请输入Y or N')
    if b == 'Y':
        n =0
    else:
        print('退出登录')
```

### **作业五**

```
n = 0
while n < 3:

    usename = input("请输入用户名")
    pwd = input("请输入密码")
    if usename == 'zhangsan' and pwd == 123:
      print("输入正确登陆成功")
      break
    else:
        d = 2
        d = d - n
        print('你还有%d次机会'%d)
        n += 1
else:
    print('登陆失败')
```

## 3.数据类型

### **整型**

```python
# 整型是十进制整数的统称

# 1.定义整型
age = 18
print(type(age))

# 2.任意进制数字，输出时总是十进制表示
v1 = 0b1000
print(v1)
v1 = 0x12
print(v1)

# 3.其他
# py3中整型只有Int 且没有长度限制

# 4.py3相除默认保留小数位
v1 = 3 / 2
print(v1)
```

### **布尔**

```
1.仅有false和true两个值
# 2转化
# 数字转布尔：0为false,其他都转为true
# 字符串转布尔：空字符串为false,其他的为true
```

### **字符串**（重点）

```python
# 1.表示
v1 = 'momo'
v1 = ''' 
当你在穿山越岭的另一边
我在孤独的路上没有尽头
'''
# 2.转大小写   .upper()   .lower()
msg = 'momo'
print(msg.upper())
print(msg.lower())

# 3.去除字符两边空格(换行、制表符) .strip()
'''
去除两边空格   .strip()
去除左边空格   .lstrip()
去除右边空格   .rstrip()

'''
msg = ' momomo'
print('---'+msg.lstrip()+'---')
msg = 'momomo '
print('----'+msg.rstrip()+'---')
msg = ' momomo '
print('---'+msg.strip()+'---')

# .验证码实例
'''
假设需输入的验证码是Yn5Us,验证输入的验证码是否正确，
'''
# while True:
#     code = input('请输入验证码：')
#     value = code.strip().lower()
#     if value == 'yn5us':
#         print('验证码输入正确')
#         break
#     else:
#         print('验证码错误！')

# 4.判断字符串是否为十进制数 .isdecimal()  会得到一个布尔值
# while True:
#     age = input('请输入你的年龄')
#     flag = age.isdecimal()
#     if flag:
#         age = int(age)
#         break
#     else:
#         print('请输入数字!')

# 5.字符串内容替换.replace()   常用于过滤敏感词汇
# content = input('请说出你的想法：')
# content = content.replace('操','*')
# content = content.replace('你妈','*')
# print(content)

# 6.字符串切割  得到一个列表
# .split() :从左到右进行切割
#             .rsplit() :从右到左进行切割
# content = 'momomo,苹果,香蕉,饺子'
# result = content.split(',')   #彼此分隔开
# result2 = content.split(',',1)
# result3 = content.rsplit(',',1)
# print(result)
# print(result2)
# print(result3)

# 7.判断以xx开头(.startswith()) 或者以xx结尾(.endswith())的字符串
# v1 = '和梓默一起学python吧，人生苦短，我学python'
# result1 = v1.startswith('和梓默')
# result2 = v1.endswith('梓默')
# print(result1,result2)

# 8.字符串拼接 *  .join()
# data_list = ['中国','特朗普','小日本']
# result = '干掉'.join(data_list)
# print(result)

# 9.字符串格式化.format()*
# content = '我叫{0},年龄{1}'.format('zhangsan',19)
# print(content)

# 10.字符串编码encode()
name = '璐璐'
v1 = name.encode('utf-8')
v2 = name.encode('gbk')
print(v1)
print(v2)
```

### **公有方法**

```python
# 1.获取字符串长度len()
# name = 'momomo'
# print(len(name))
#
# # 2.索引
# content = 'momoailulu'
# print(content[0])
# print(content[1])
# print(content[2])
# print(content[10])  #超出最大索引值会报错
#
# print(content[-1])   #反向查找
# print(len(content))
# print(content[len(content)-1]) #字符串长度-1为最大索引值

# 练习一：正向取出字符串中所有字符
# content = 'momoailulu'
# index = 0
# while index <= len(content)-1:
#     char = content[index]
#     print(char)
#     index += 1

# 练习二：反向取出字符串中所有字符
# content = "momoailulu"
# index = 0
# while index >= -len(content):
#     char = content[index]
#     print(char)
#     index -= 1

# 练习三： 计算字符串中的数字个数
# content = "momoailulu5201314"
# index = 0
# total = 0
# while index <= len(content)-1:
#     flag = content[index].isdecimal()
#     if flag:
#         total += 1
#     index += 1
# print(total)

# 3.切片
# 获取字符串中某段连续的字符
content = 'oldboy'
print(content[2:4]) #取出db，前取后不取
print(content[3:])#从索引3开始，取出剩余的字符：boy
print(content[:5]) #从头开始取，取到索引值4，为：oldbo
print(content[:]) #从头取到尾
print(content[2:-2])#从索引2开始取到倒数第三 为db
print(content[-3:])#取出最后三个字符：boy

# 4.步长
# 跳步选择数据
char = 'oldboy'
print(char[0:5:2])     #odo
print(char[-1:0:-2])   #倒数开始取，步长为2
print(char[::1])     #从左到右输出步长为1   oldboy
print(char[::-1])    #从右到左反方向输出

# 5.for循环
# 循环打印字符串中的每个字符   for > while
# 死循环 while >for
# 有穷的尽量用for ,无穷的用while
content = 'momoailulu'
for item in content:
    print(item)
content = '时间走的太快，你们都已离开'
for item in content:
    if item == '时':
        continue
    print(item)
```

## 4.条件判断

### **单分支**

```python
gender = input('请输入性别：')
if gender == '男':
    print('请结账')
```

### **双分支**

```python
#用户输入性别，如果是男孩，则输入请结账，如果是女孩则输入请面单
gender = input('请输入性别')
if gender == '男':
    print('请结账')
else:
    print('请免单')
```

### **多分支**

```python
gender = input('请输入性别：')
if gender == '男':
    print('请结账')
elif gender == '女':
    print('请免单')
else:
    print('滚')
```

### **if 嵌套**

```python
message = '''欢迎致电10086
1.话费查询
2.流量服务
3.业务办理
4.人工服务
'''
print(message)
index = input('请选择你的服务：')
index = int(index)
if index == 1:
    print("话费查询")
elif index == 2:
    print("流量服务")
elif index == 3:
    print("业务办理")
    content = '''
1.修改密码
2.更改套餐
3.停机
 '''
    print(content)
    value = int(input("请输入你要办理的业务"))
    if value == 1:
        print('修改密码')
    elif value == 2:
        print("更改套餐")
    elif value == 3:
        print("停机")
```

### 练习题

## 5.循环与运算符

### **break: 跳出当前循环**

```
# 实例1
# while True:
#     print('benbentu')
#     break

# 实例二
while True:
    print('benbentu')
    while True:
        print(666)
        break
    break
```

### **countinue:跳出本次循环执行下次循环**

```
count = 1
while count <= 10:
    if count == 7:
        count = count + 1
        continue
    print(count)
    count = count + 1
```

### **while循环**

```
# 实例一  输出1到10
# count = 1
# while count <= 10:
#     print(count)
#     count = count + 1

#实例二    输出1 2 3 4 5 6 8 9 10
#
count = 1
while count <= 10:
    if count != 7:
        print(count)
    count += 1
# 写法二
# count = 1
# while count <= 10:
#     if count == 7:
#         pass
#     else:
#         print(count)
#     count = count + 1
```

### **字符串格式化**

```
# %s   用于格式化字符串
# name = input('请输入你的名字')
# age = input('请输入你的年龄')
# school = input('请输入你的学校')
# info = '我叫%s,年龄%s，在%s学校就读'%(name,age,school)
# print(info)


# %d  用于格式化数字
# name = input('请输入你的名字')
# age = int(input('请输入你的年龄'))
# info = '我叫%s,年龄%d岁'%(name,age)
# print(info)

# %%  用于格式化字符%
# name = input('请输入你的姓名：')
# info = '我叫%s,现在的手机电量为50%%'%(name,)
# print(info)

# 小练习
name = input('name:')
age = int(input('age:'))
job = input('job:')
hobbie = input('hobbie')
msg = '''
---------info of benbentu-------
      name: %s
      age: %d
      job: %s
      hobbie:%s
---------end-------------
'''
print(msg%(name,age,job,hobbie))
```

### **数据类型转换**

```
#字符串转成数字
# v1 = '666'
# v2 = int(v1)
# print(v2)

#其他转布尔
# 0：false   非0：true
# v1 = -1
# v2 = bool(v1)
# print(v2)
#字符串转布尔   空为false  非空字符为true
v1 = ''
v2 = bool(v1)
print(v2)
```

### **是否包含**

```
value = '我是中国人'
v1 = '中国' in value
print(v1)
while True:
    content = input('请输入内容：')
    if '退款' in content:
        print('包含敏感字符')
    else:
        print(content)
        break
```

### **比较运算符**

```
a = 1
b = 9
c = a > b
print(c)
```

### **算数运算符**

```
#取余 %
# 打印1到100之间的奇数
# count = 1
# while count <= 100:
#     if count % 2 != 0:
#         print(count)
#     count += 1

#幂函数**   表示2的八次方
# num = 2 ** 8
# print(num)

# 除（返回整数部分）//
# num = 9 / 1
# num2 = 9 // 2
# print(num)
# print(num2)

# 练习
# 1.求1到100和
count = 1
sum = 0
while count <= 100:
    sum = sum + count
    count = count + 1
print(sum)
```

### **赋值运算符**

```
count = 1
sum = 0
while count <= 100:
     sum = sum + count  #sum += count
     count = count + 1  #count += 1
print(sum)
```

### **运算符优先级**

```
# 1.算数运算符 > 比较运算符
# if 2 + 20 > 20 :
#     print('真')
# else:
#     print('假')

# 2 比较  > 逻辑
# if 1 > 2 and 2 < 10:
#     print('成立')
# else:
#     print('不成立')

# 3 逻辑运算  not > and > or
if not 1 and 1 > 2 or 3 == 8:
    print('真')
else:
    print('假')
```

### **逻辑运算**

```
# 1.逻辑与  and
# 左  and  右
# 左为true的话，返回右侧值
# 左侧为false时，直接返回左侧值

# 练习1
# v1 = 1==1 and 2>3
# print(v1)

#练习2
# name = input('请输入姓名')
# if name == 'benbentu' and 1 == 1:
#     print('真')
# else:
#     print('假')

#练习3
# v1 = 2 and -1
# print(v1)

#练习4
# v1 = '' and 'hello'
# print(v1)


#逻辑或   or
# 左侧为true 返回左侧
# 左侧为false 返回右侧
#练习1
# v1 = 1 == 1 or 2> 3
# print(v1)

#练习2
# while 1 == 2 or 2 == 9:  # while为true时执行循环
#     print('来了老妹')

# 练习3
# v1 = 0 or 'hello'
# print(v1)


#企业面试题
# 混合出现时先处理and后处理or   0为false
# v1 = 1 and 6 or 8 and 0 or ''
# print(v1)

# 例1
# v1 = 0 or 4 and 3 or 7 or 9 and 6
# print(v1)
# 例2
# v2 = 8 or 3 and 4 or 2 and 0 or 9 and 7
# print(v2)
# 例3
v3 = 0 or 2 and 3 and 4 or 6 and 0 or 3
print(v3)
```

## 6.文件

### **创建文件：**

```
f = open('zimozi.txt','w',encoding='utf-8')
```

### **写入文件：**

```
# f = open('zimozi.txt','w',encoding='utf-8')
# f.write('梓默子九距')
# f.close()
```

### **读文件：**

```
# f = open('zimozi.txt','r',encoding='utf-8)
# print(f.read())
# f.close()

read  readline  readlines的区别**：

read           读取全部文件数据并原样返回

readlines   读取全部文件并以列表方式返回数据

readline    只读取一行数据
```

### **添加内容到文件：**

```
# f = open('zimozi.txt','a',encoding='utf-8')
# f.write('梓默zi爱璐璐zi')
# f.close()
```

### **二进制文件（一般用于图片视频的插入）**

```
# import requests
# a = requests.get('http://pic-bucket.ws.126.net/photo/0003/2019-07-26/EL0FD9K000AJ0003NOS.jpg').content
# f = open('宋祖儿.jpg','wb')
# f.write(a)
# print('下载成功')
# f.close()
```

### **常用于大文件的读取**

```
# a = open('lulu.txt','r',encoding='utf-8')
# for i in a.read():
#     print(i)
```

## 7.函数思考总结

### 1.函数变量与return

###### 函数中return返回的值给变量  比如  a = func()   是说func函数返回的值（也就是return的值给变量a）
###### #当只有一个func()时，函数中要有print就返回print,不返回return的值

### 2.关于for循环的那些事......：

```python
# for i in range(10):
#      func_list.append(lambda x:x+i)    当循环中带有函数时，函数中的i值是循环运行完毕后的值，在这i的值是9
# 但是当循环中没有函数时，循环正常运行 ：
# for i in range(0,len(func_list)):
#       res = func_list[i](i)
# 这里的循环中的i值会在（o，9）循环
```

### 3.关于全能函数的那些事....

```
# def func(*arg,**kwargs):
#      print(arg,kwargs)
#
# func([12,3,*[11,112]])
#kwargs 只认字典形式的数据，使用全能函数的时候如果没有字典形式的数据时，则数据全部给arg
#arg    仅支持位置传参  将值转换为元组
```

### 4.关于闭包的那些事

```
# 概念：    函数嵌套时，当某个函数被当成对象返回时，夹带了外部变量，就形成了一个闭包，闭包是轻量级的接口性编程，类似于下面的情况
# 封装值 + 内层函数需要使用外层变量
# name = 'zimomo'
# def bar(name):
#     def inner():
#         print(name)    函数嵌套时，私有变量也就是里面函数的变量夹带了外部变量，这就是闭包
#     return inner
# v1 = bar('alex')
# v2 = bar('eric')
# v1()
# v2()
```

### 5.关于lambda和三元运算那些事

```python
# 俩都是简单函数和简单循环的简单写法
# 格式：
# lambda 变量名：return需要返回的值
# 例如：
# func = lambda x : x*10
# print(func(3))
'---------------------------------------'
# 格式：
# 结果 if 条件 else 结果
# v = print('你赢了') if a > 2 else print('你输了')
```

### 6.加盐的那些事

```python
##    加密的同时混入一段特定的字符段再进行哈希加密这就是加盐
# 例如：
# import hashlib
# def get_md5(data):
#     obj = hashlib.md5('sdfsduiu23djn4'.encode('utf-8'))
#     res = obj.hexdigest()
#     return res
# val = get_md5('123')
# print(val)
```

### 7.进制转换那些事

```
# bin()将十进制转换为二进制
# oct() 将十进制转换为八进制
# int() 将其他进制转换为十进制
# hex() 将十进制转换为十六进制
```

### 8. map（）filter（）reduce 高级内置函数那些事

```python
# map():循环遍历每个元素，将每个返回值保存到一个个新的列表中，并返回
# res = map(函数,可迭代类型)
# print(list(res))
# 例如：
# v1 = [11.,15,47]
# res = map(lambda x: x + 100,v1)
# print(list(res))
'-----------------------------------------------------'
# filter()  对每个元素利用函数进行筛选，最终获取符合条件的序列 比如筛选整性类型的值  res = filter(函数,可迭代类型)
# 例如：
# v1 = [1,2,True,'zimomo']
# res = filter(lambda x: type(x) == int,v1)
# print(list(res))
'-------------------------------------------------------'
# reduce()   对序列每个操作进行累计操作，最终获得符合条件的序列(字符串拼接;累加，累乘)
# 必须是俩参数
# import functools
# res =  reduce(函数,可迭代类型)
# 例如：
# import functools
# v1 = ['h','e','l','l','o']
# res = functools.reduce(lambda x, y : x + y, v1)
# print(res)
```

### 9.数学内置函数那些事

```python
# abs() 绝对值    float()转换为浮点  max()找最大值  min() 找最小值  sum()  相加
# divmod() 两数相除，获取商和余数
# 例如：
# print(divmod(9,5))
```

## 8.面向对象

### 1.面向对象三大特性

#### 封装

```python
# class Person:  ##Person类
#     def __init__(self,name,age,sex): ##用 _init_将数据封装到对象，调用方法时，方便使用
#         self.name = name
#         self.age = age
#         self.sex = sex
#
#     def show(self):   ##方法show
#         print(self.name)
#         print(self.age)
#         print(self.sex)
#
# p1 = Person('zimo','18','男')   ##将各项数据封装到p1中，调用方法时方便使用
# p1.show()      #p1对象
```

#### 继承

```python
# 继承中查找顺序先去子类中找，子类没有再去父类，引用谁先去谁
# class Animal():
#     def eat(self):
#         print('eat')
# class Dongwu():
#     def jiao(self):
#         print('叫')
#
# class cat(Animal,Dongwu):     ##多继承
#     def drink(self):
#         print('drink')
#
# obj = cat()
# obj.eat()       #先去cat中找eat，没有的话再去父类animal中找
# obj.drink()
# obj.jiao()
```

#### 多态

```
# 多态意味着变量并不知道引用的对象是什么，
# 根据引用对象的不同表现不同的行为方式。)
# # 指多种形态，多种类型，又称为鸭子模型
```

### 2.类的变量与方法

#### 变量

```
# 变量：
# 在对象中创建的变量为实例变量
# 在类中创建的变量为类变量
# 关系：先去对象中找，对象没有再去类中找。先去自己类中找，没有的话再去父类
# class Foo:
#     city = '北京'              #city就为类变量
#     def __init__(self,name):
#         self.name = name      #name就为实例变量
#     def info(self):
#         pass
#
# obj1 = Foo('zimo')
# obj2 = Foo('lulu')
#
# print(obj1.name,obj2.name)
# print(Foo.city)
# print(obj1.city,obj2.city)
```

#### 方法

```
# 成员方法：普通的def创建方法
# 静态方法：@staticmethod
# 类方法： @classmethod（仅python有）
# 属性方法：@property
```

##### 静态方法

```
# 静态方法：参数不限
# class Foo:
#     @staticmethod
#     def f1():
#         print(123)
#
# Foo.f1()     ##类本身调用
# obj = Foo()  ##类实例调用
# obj.f1()
```

##### 类方法

```
# 类方法：  仅python有且至少有个cls参数
# class Foo:
#     @classmethod
#     def f2(cls,a,b):
#         print(cls)   #cls指当前的类
#         print(a,b)
#
# Foo.f2(1,2)      可直接  类.方法 调用
```

##### 属性方法

```
# 属性方法：
# class Foo:
#     @property  ##装饰器
#     def f3(self):
#         print(123)
#         return 666
#
# obj = Foo()
# a = obj.f3     #调用时不用加（）
# print(a)
```

### 3.私有

```
# __xx：双下划线，私有化属性或方法，无法在外部直接访问
```

### 私有实例变量

```
# 私有实例变量：
# class Foo:
#     def __init__(self,name):
#         self.__name = name
#     def func(self):
#         print(self.__name)
#
# obj = Foo('zimo')
# print(obj.__name)   #从外部访问会报错
# obj.func()          #先进入内部才能访问
```

#### 私有类变量

```
# 私有类变量
# class Foo:
#     __x = 1
#     @staticmethod
#     def func():
#         print(Foo.__x)
# print(Foo.__x) #报错
# Foo.func()
```

#### 私有方法

```
# 私有方法
# class Foo:
#     def __fun(self):
#         print(123)
#     def show(self):
#         self.__fun()
#
# obj = Foo()
# # obj.__fun()   #进入类内部也无法直接访问私有方法
# obj.show()     ##只能进入类内部通过执行公有方法才可以访问
```

#### 强制访问

```
# 强制访问：
# class Foo:
#     def __init__(self,name):
#         self.__x = name
#
# obj = Foo('zimo')
# print(obj._Foo__x)
```

#### 构造方法

```
# 构造方法 __new__()
# 在初始化方法之前，用于创建空对象也就是构造对象
# class Foo:
#     def __init__(self,a1):
#         self.a1 = a1
#         print(self.a1)
#     def __new__(cls, *args, **kwargs):   ##先于init执行，可以用作限制条件
#         return object.__new__(cls)
#
# obj = Foo('zimozi')
```

#### str方法

```
# __str__：
# 只有在打印对象时，会自动调用该方法，并将其返回值在页面显示
# class Foo:
#     def __str__(self):
#         return 'hello'
#
# obj = Foo()
# print(obj,type(obj))
```

#### dict方法

```
# __dict__
# class Foo:
#     def __init__(self,name,age):
#         self.name = name
#         self.age = age
#
# obj = Foo('zimozi',19)
# val = obj.__dict__   #去对象中找到所有的变量，并将其转化为字典
# print(val)
```

#### 上下文管理器

```
# 上下文管理器
# class Foo:
#     def __enter__(self):  #打开文件
#         self.x = open('a.txt',mode='a',encoding='utf-8')
#         return self.x
#     def __exit__(self, exc_type, exc_val, exc_tb):  # 关闭文件
#         self.x.close()
# with Foo() as f:
#     f.write('zimozi')
#     f.write('luluzi')
#     ## 先执行打开文件  然后写入内容 最后关闭文件
```

#### 两个对象相加

```python
# 两个对象相加
# class Foo:
#     def __add__(self, other):
#         return 123
# obj1 = Foo()
# obj2 = Foo()
# val = obj1 + obj2
# print(val)
```

### 5.嵌套

```python
# class School:
#     def __init__(self,title,addr):
#         self.title = title
#         self.address = addr
# class Classname:
#     def __init__(self,name,school_obj):
#         self.name = name
#         self.school = school_obj
#
# s1 = School('上海','北京')      ##封装s1
# s2 = School('上海','浦东')      ##封装s2
#
# c1 = Classname('zimozi',s1)   ##封装c1，并给变量，s1的引入就为嵌套
# print(c1.name)
# print(c1.school.address)      ## 对象.变量来调用
```

### 6.内置函数补充

```python
# issubclass(子类，基类)：
# 判断一个类是否是另一个类的子类，返回布尔类型数据
# class Base:
#     pass
# class Foo(Base):
#     pass
# class Bar():
#     pass
#
# print(issubclass(Bar,Base))
# print(issubclass(Foo,Base))


# isinstance()：
# 判断一个对象是否是某个类的实例
# class Base:
#     pass
# class Foo:
#     pass
#
# obj  = Foo()
# print(isinstance(obj,Foo))
# print(isinstance(obj,Base))


# super：
# super().func()    去父级找func（）函数
# class Base:
#     def func(self):
#         print('base func')
# class Foo(Base):
#     def func(self):
#         super().func()   #去父类中找func，并执行
#         print('foo func')
#
# obj = Foo()
# obj.func()
```

## 9.模块

### 1.datetime模块

```python
# from datetime import datetime
# 获取当前本地时间
# v1 = datetime.now()
# print(v1)
# 获取当前utc时间
# v3 = datetime.utcnow()
# print(v3)


# 以上获取的数据均为datetime类型
# 将datetime转换为字符串，一般用于页面显示或者数据储存
# v4 = datetime.now()
# val = v4.strftime('%Y-%m-%d %H:%M:%S')
# print(val)


# datetime与时间戳相互转换
# 时间戳转当前时间
from datetime import datetime,timezone,timedelta
import time
ctime = time.time()
v = datetime.fromtimestamp(ctime)
print(ctime,v)
# 当地时间转时间戳
v1 = datetime.now()
val = v1.timestamp()
print(v1,val)
```

### 2.json模块

#### 序列化

```
# 序列化：将字符 列表 字典 转化为json数据的过程，成为序列化
# 反序列化：还原过来叫反序列化
# json格式要求:
# 最外层是容器类型[列表或字典]
# 字符串必须是双引号 " "
# json只有int str list dict bool 这几种数据类型
#元组会自动转换为列表进行序列化，集合不能序列化
```

#### 反序列化

```python
# 2.反序列化
# import json
# v2 = '["momoailulu",true,"hello"]'
# v3 = json.loads(v2)
# print(v2)
# print(v3)
```

#### 序列中保留中文格式

```python
# import json
# v = {'k1':'zimoailulu','k2':'璐璐爱梓默'}
# v1 = json.dumps(v)
# print(v1)
# v2 = json.dumps(v,ensure_ascii=False)
# print(v2)
```

### 3.os模块

#### 显示文件绝对路径

```python
import os
path = 'a.mp4'
v1 = os.path.abspath(path)
print(v1)
```

#### 上级目录

```
# 2.上级目录     os.path.dirname()
# import os
# path = r'E:\PyCharm 2020.2.3\2022\模块\a.mp4'
# print(os.path.dirname(path))
```

#### 路径拼接

```
# 3.路径拼接     os.path.join(1,2)
# import os
# path = 'E:\PyCharm 2020.2.3\2022\模块\a.mp4'
# v = 'b.txt'
# res = os.path.join(path,v)
# print(res)
# v1 = 'sss'
# v2 = 'fff'
# res = os.path.join(path,v1,v2,v)
# print(res)
```

#### 查看目录所有文件

```
# import os
# path = os.listdir(r'E:\PyCharm 2020.2.3\2022\模块')
# for file in path:
#     print(file)

# 面试题：
# import os
# path = os.walk(r'E:\PyCharm 2020.2.3\2022\模块')
# for a,b,c in path:
#     for item in c:
#         file = os.path.join(a,item)
#         print(file)
```

#### 创建目录

```
# 5.创建目录
# import os
# file_path = r'momo\lulu\a.text'
# file_folder = os.path.dirname(file_path)
# if not os.path.exists(file_folder):
#     os.makedirs(file_folder)
# with open(file_path,mode='w',encoding='utf-8') as f:
#     f.write('123')
```

#### 重命名文件

```
# 6.重命名文件
# 文件目录都可修改
# import os
# os.rename('11.txt','momoailulu.txt')
```

### 4.print功能补充

```python
# print('str')默认换行
# print('str',end='')取消换行
# /r使光标回到当前行起始位置
print('hello',end='')
print('hh',end='')

print('hello\r',end='')  ##会打印hello，光标回到当前行起始位置，重新打印时，会抹去hello 然后打印haha
print('haha',end='')
```

### 5.shutil模块

```python
import shutil
# 删除目录（和目录下所有文件）
# shutil.rmtree('momoailulu')

# 重命名
# shutil.move('momoailulu.txt','luluaimomo.txt')

# 压缩文件
# shutil.make_archive('momo','zip','momo')

# 解压文件
# shutil.unpack_archive('momo.zip',extract_dir=r'E:\PyCharm 2020.2.3\2022\模块\luluaimomo',format='zip')
```

### 6.sys模块

```
# sys模块
# import sys
# a = [1,2,3]
# print(sys.getrefcount(a))     ##获取变量地址引用次数
#
# v = sys.getrecursionlimit()   ##py默认支持的递归数量
# print(v)

# 2.进度显示
# import time
# for i in range(1,101):
#     msg = '%s%%\r'%(i,)
#     print(msg,end='')
#     time.sleep(0.05)

# 3.sys.argv
# sys.argv[0]:程序本身路径
# sys.argv[1]:获取用户执行脚本时传入的参数

# 删除文件
# import sys
# print(sys.argv)
# content = input('请输入路径').strip()
# sys.argv.append(content)
# if len(sys.argv) == 2:
#     path = sys.argv[1]
#     import shutil
#     shutil.rmtree(path)
# else:
#     print('输入的参数有误')

# 4.sys.path
# python 导入模块的路径
import sys
for path in sys.path:
    print(path)
```

### 7.time模块

```
import time
v1 = time.time()  ##获取当前时间
print(v1)
# time.sleep(5)   等待的秒数
# time.timezone    与伦敦相差的秒数
```

### 8.字节型数据

```python
# 字节型数据   使用utf-8编码的二进制
# 字符串型数据 ： 使用unicode编码的二进制
import json
import pickle
v1 = {1,2,3,'梓默子'}
v2 = pickle.dumps(v1)
print(v2,type(v2))
v3 = ['zimozi']
v4 = json.dumps(v3)
print(v4,type(v4))
```

### 9.异常处理

```
# 当程序代码运行为防止未知错误，向用户显示友好信息，常进行异常处理    抛异常
# try:
#     val = input('请输入数字：')
#     num = int(val)
# except Exception as e:
#     print('操作异常')

# 实例二：
import requests
try:
    ret = requests.get('http://www.baidu.com')
    print(ret.text)
except Exception as e:
    print('请求异常')
```

### 10.自定义模块

```
# 1.引入自定义的py文件
# import hello
# hello.f1()
# 示例一：
# from xxx import x,y     #仅引入x，y功能
# from xxx import *     引入所有功能

# from xxx import func as f      #给模块中func起个名
# def func():
#     print('123')
# f()


# 总结：
# 模块和要执行的py文件在同一目录并且需要很多模块功能时，推荐用import模块
# 其他的推荐用 from 模块 from 模块
```

## 10.深浅拷贝

### 不可变类型

```python
#深浅拷贝等于赋值，完全共享内存地址
import copy
v1 = 1000
v2 = copy.copy(v1)
v3 = copy.deepcopy(v1)
print(v2)
print(v3)
```

### 元组

```python
## 对于不含可变类型的元组,效果等同于赋值
import copy
v1 = (1,2,3)
v2 = copy.copy(v1)
v3 = copy.deepcopy(v1)
print(v2)
print(v3)
print(id(v1),id(v2),id(v3))
v4 = (1,2,[1,2])
print(id(copy.copy(v4)))
print(id(copy.deepcopy(v4)))
```

### 可变类型

```python
## 深浅拷贝仅拷贝最外层的内存地址并存放其他内部共享地址
import copy
v1 = [1,2,[3,2]]
v2 = copy.copy(v1)
v3 = copy.deepcopy(v1)
print(v1)
print(v2)
print(v3)
print(id(v1[0]),id(v2[0]),id(v3[0]))
```

## 11.装饰器

### 列表推导式

```
# 目的：方便生成一个列表
# v1 = [i for i in range(10)]
# print(v1)
# v2 = [i + 100 for i in range(10)]
# print(v2)
# v3 = [99 if i > 5 else 66 for i in range(10)]
# print(v3)
#
# def func():
#     return 100
# v4 = [func for i in range(10)]
# print(v4)
#
# v5 = [lambda : 100 for i in range(10)]
# print(v5[5]())
#
# v6 = [lambda : i for i in range(10)]
# print(v6[6]())
#
# v8 = [lambda x:x*i for i in range(10)]
# a = v8[0](2)
# print(a)

# 面试题：
# def num():
#     return [lambda x:x+i for i in range(4)]
# print([m(2) for m in num()])

# 筛选：
v9 = [i for i in range(10) if i > 5]
print(v9)
```

### 基本装饰器

```
# 装饰器：再不改变原函数内部代码基础上，在原函数执行之前和之后自动执行某个功能
# 1.引入
# def func(arg):
#     def inner():
#         return arg()
#     return inner
# def index():
#     print('123')
#     return '666'
#
# v = func(index)
# index = v
# index()
# # 书写二：
# def func(arg):
#     def inner():
#         v = arg()
#         return v
#     return inner
# @func  ###@func 等于  index = func(index)
# def index():
#     print('123')
#     return '666'
# index()

# 2.运用场景
# 1.场景一
# time.sleep(n)    代表延迟n秒往下执行
# 计算函数执行时间
# import time
# def func1():
#     time.sleep(2)
#     print('func1')
# def func2():
#     time.sleep(1)
#     print('func2')
# def func3():
#     time.sleep(1.5)
#     print('func1.5')
# start1 = time.time()      ##time.time:返回当前时间
# func1()
# end1 = time.time()
# print(end1 - start1)
#
# start2 = time.time()
# func2()
# end2 = time.time()
# print(end2 - start2)
#
# start3 = time.time()
# func3()
# end3 = time.time()
# print(end3 - start3)
'-----------------------------使用装饰器改写------------------------------------'
# import time
# def wrapper(func):
#     def inner():
#         start_time = time.time()       ##函数执行前
#         v = func()                     ## v = func(),调用函数
#         end_time = time.time()         ##函数执行后
#         print(end_time - start_time)
#         return v
#     return inner
# @wrapper                               ##执行到这里时，会调用wrapper函数，并将func1当做参数传入
# def func1():                           ##执行函数时自动触发装饰器
#     time.sleep(2)
#     print('func1')
# @wrapper
# def func2():
#     time.sleep(1)
#     print('func2')
# @wrapper
# def func3():
#     time.sleep(1.5)
#     print('func3')
# func1()
# func2()
# func3()


# 总结
# 改写后的装饰器编写格式（有参数的）
# def x(fun):
#     def y(name):
#         print('luluzi')
#         a = fun(name)
#         print(a)
#     return y
# # 装饰器应用格式：
# @x
# def fun(name):
#    print('zimozi')
#    return name
#
#
# fun('zimo')


import time
def ceshi(xinrenxingming):
    def ceshi1():
        print('结婚证录入工作')
        print('姓名：')
        xinrenxingming()
        print('结婚证录入成功')

    return ceshi1
@ceshi
def zimo():
    time.sleep(2)
    print('zimo')
@ceshi
def lulu():
    time.sleep(2)
    print('lulu')

zimo()
lulu()
```

### 带参数的装饰器

```python
# def x(n):
#     def func(arg):
#         def inner(*args,**kwargs):
#             v = arg(*arg,**kwargs)
#             return v
#         return inner
#     return func
# @x(9)
# def index():
#     print('zimozi')


# def x(n):
#     print(n)
#     def x(fun):
#         def y(name):
#           print('luluzi')
#           a = fun(name)
#           print(a)
#         return y
#     return x
# # 装饰器应用格式：
# @x('longlongzi')
# def fun(name):
#    print('zimozi')
#    return name
#
#
# fun('zimo')

# 练习一
# def xxx(n):
#     def func(arg):
#         def inner(*args,**kwargs):
#             v = []
#             for i in range(n):
#                 data = arg(*args,**kwargs)
#                 v.append(data)
#             return v
#         return inner
#     return func
#
# @xxx(7)
# def index():
#     print('zimozi')
# v = index()
# print(v)
```